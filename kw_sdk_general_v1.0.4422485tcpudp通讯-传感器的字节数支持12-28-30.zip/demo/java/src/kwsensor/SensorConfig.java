package kwsensor;


public class SensorConfig {
    public int linkMode;
    public int decodeMode = -1;
    public float[] paras;
    public String sensorIp;
    public int sensorPort = 5152;
    public String localIp;
    public int localPort = 8886;
    public String serialPortName;
    public int baudRate = 460800;
}
