package kwsensor;


public class KwSensorJNI {
	
	static {
		System.load(new java.io.File("kw-java-lib.dll").getAbsolutePath());
	}
	
	public native static String kwGetSdkVersion();
	
	public native static int kwSetConfig(int device_idx, SensorConfig cfg);
	
	public native static int kwStartCapture(int device_idx);
	
	public native static int kwStopCapture(int device_idx);
	
	public native static int kwGetForceDataF(int device_idx, float[] data,
			long[] frameNum, long[] totalBytes);
	
	public native static int kwGetCurrentForceData(int device_idx, float[] data);
}
