package test;

import java.util.Arrays;

import kwsensor.KwSensorJNI;
import kwsensor.SensorConfig;



class MyThread extends Thread {
	public float[] force;
	public boolean isCapturing = false;
	public long[] frameNum;
	public long[] totalBytes;
	
	@Override
    public void run() {
		System.out.println("thread starting");
		
		// 可阻塞使用的函数api的调用
//    	while (isCapturing)
//    	{
//    		if (KwSensorJNI.kwGetCurrentForceData(0, force) == 0)
//    		{
//    			System.out.println("Force: " + Arrays.toString(force));
//    		}
//    	}
		
		// 不可阻塞使用的函数api调用
		while (isCapturing)
		{
			if (KwSensorJNI.kwGetForceDataF(0, force, frameNum, totalBytes) == 0)
			{
				System.out.printf("Frame: %d | Bytes: %d | Force: %s%n",
		                frameNum[0],                // 取long[]第一个元素
		                totalBytes[0],              // 取long[]第一个元素
		                Arrays.toString(force)      // 打印float数组
		            );
			}
		}
		
    	System.out.println("thread end");
    }
}


public class Test {
	public static void main(String[] args)
	{
		SensorConfig cfg = new SensorConfig();
		cfg.linkMode = 2;
		cfg.decodeMode = 2;
		cfg.localIp = "192.168.1.100";
		cfg.localPort = 8886;
		cfg.sensorIp = "192.168.1.101";
		cfg.sensorPort = 5152;
		cfg.serialPortName = "COM6";
		cfg.baudRate = 460800;
		
		if (KwSensorJNI.kwSetConfig(0, cfg) != 0)
		{
			return;
		}	
		
		MyThread t1 = new MyThread();
		t1.force = new float[6];
		t1.frameNum = new long[1];
		t1.totalBytes = new long[1];
		t1.isCapturing = true;
		
		if (KwSensorJNI.kwStartCapture(0) != 0)
		{
			return;
		}
		
		System.out.println("open sensor success");
		
		t1.start();
		
		 try {
	            Thread.sleep(10000);
	            t1.isCapturing = false;
	            t1.join(); 
	        } catch (InterruptedException e) {
	            e.printStackTrace();
	        }
			 
		 if (KwSensorJNI.kwStopCapture(0) == 0)
		 {
			 System.out.println("close sensor success");
		 }
	}
}









