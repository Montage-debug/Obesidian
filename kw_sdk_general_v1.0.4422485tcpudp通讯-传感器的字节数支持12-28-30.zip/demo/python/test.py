import ctypes
import sys
import os
import time


class SensorConfig(ctypes.Structure):  
    _fields_ = [("linkMode",ctypes.c_int),
            ("decodeMode",ctypes.c_int),
            ("paras",ctypes.POINTER(ctypes.c_float)),
            ("sensorIp", ctypes.c_char_p),
            ("sensorPort",ctypes.c_ushort),
            ("localIp", ctypes.c_char_p),
            ("localPort", ctypes.c_ushort),
            ("serialPortName", ctypes.c_char_p),
            ("baudRate", ctypes.c_int),
            ]  
    
    def __init__(self):
        super().__init__()
        self.linkMode = -1
        self.decodeMode = -1
        self.paras = None
        self.sensorIp = None
        self.localIp = None
        self.sensorPort = 5152
        self.localPort = 8886
        self.serialPortName = None
        self.baudRate = 460800


if sys.version_info >= (3, 8):
    os.add_dll_directory(os.path.abspath("."))


# windows环境
dll = ctypes.windll.LoadLibrary("kw-c-libd.dll")
# linux环境 
# dll = ctypes.cdll.LoadLibrary("./libkw-c-lib.so")


cfg = SensorConfig()

######################################  串口、tcp、udp的连接区别


################################ 串口
# cfg.linkMode = 0 ### 串口设置0， tcp设置1， udp设置2
# cfg.decodeMode = 2 ### 28字节设置为0， 12字节设置为1， 30字节设置为2
# cfg.serialPortName = b"COM6" ### windows一般为COM
# cfg.baudRate = 460800

# cfg.paras = (ctypes.c_float * 6)(1.0, 1.0, 1.0, 1.0, 1.0, 1.0) # 注意12字节时需要设置, 其余情况可不设置。具体参数根据具体型号咨询


################################ Tcp
# cfg.linkMode = 1
# cfg.decodeMode = 2 # 参数含义同上
# cfg.sensorIp = b"192.168.1.100"
# cfg.sensorPort = 5152
# cfg.localIp = b"192.168.1.101"
# cfg.localPort = 8886

# cfg.paras = (ctypes.c_float * 6)(1.0, 1.0, 1.0, 1.0, 1.0, 1.0) # 注意12字节时需要设置。具体参数根据具体型号咨询

################################ Udp
cfg.linkMode = 2
cfg.decodeMode = 2 # 参数含义同上
cfg.sensorIp = b"192.168.1.101"
cfg.sensorPort = 5152
cfg.localIp = b"192.168.1.100"
cfg.localPort = 8886
cfg.paras = (ctypes.c_float * 6)(1.0, 1.0, 1.0, 1.0, 1.0, 1.0) # 注意12字节时需要设置。具体参数根据具体型号咨询



if dll.kwSetConfig(0, ctypes.byref(cfg)) != 0:
    print("error")

if dll.kwStartCapture(0) != 0:
    print("error")
    
    
t = time.time()

data = (ctypes.c_float * 6)()


# for i in range(100):
#     if (dll.kwGetCurrentForceData(0, data) == 0):
#         print(list(data))
#     time.sleep(0.1)


frameNum = ctypes.c_uint64(0)
totalBytes = ctypes.c_size_t(0) 


while (time.time() - t < 5):
    if (dll.kwGetForceDataF(0, data, ctypes.byref(frameNum), ctypes.byref(totalBytes)) == 0):
        print(f"{list(data)}")
print(f"totalBytes: {totalBytes}")
   
dll.kwStopCapture(0)
dll.kwResetConfig(0) # 重置配置

print("close success")