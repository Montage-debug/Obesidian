﻿using System;
using System.Runtime.InteropServices;
using System.Text;


// 结构体的参数含义见文档说明
[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
public struct SensorConfig
{
    public int linkMode;
    public int decodeMode;

    [MarshalAs(UnmanagedType.LPStr)]
    public string deviceInfo;

    [MarshalAs(UnmanagedType.LPStr)]
    public string sensorIp;

    public ushort sensorPort;

    [MarshalAs(UnmanagedType.LPStr)]
    public string localIp;

    public ushort localPort;

    [MarshalAs(UnmanagedType.LPStr)]
    public string serialPortName;

    public int baudRate;
}

public static class NativeMethods
{
    // DLL 名称应替换为实际生成的 DLL 文件名
    [DllImport("kw-c-libd.dll", CallingConvention = CallingConvention.StdCall)]
    public static extern int kwSetConfig(int device_idx, ref SensorConfig config);

    [DllImport("kw-c-libd.dll", CallingConvention = CallingConvention.StdCall)]
    public static extern int kwResetConfig(int device_idx);

    [DllImport("kw-c-libd.dll", CallingConvention = CallingConvention.StdCall)]
    public static extern int kwStartCapture(int device_idx);

    [DllImport("kw-c-libd.dll", CallingConvention = CallingConvention.StdCall)]
    public static extern int kwGetForceDataF(
        int device_idx,
        [Out] float[] data,
        out ulong frameNum,
        out UIntPtr totalBytes);

    [DllImport("kw-c-libd.dll", CallingConvention = CallingConvention.StdCall)]
    public static extern int kwGetCurrentForceData(int device_idx,[Out] float[] data);

    [DllImport("kw-c-libd.dll", CallingConvention = CallingConvention.StdCall)]
    public static extern int kwStopCapture(int device_idx);
}


class program
{
    static void Main()
    {
        // 注意config的各个参数的含义，见文档说明
        SensorConfig config = new SensorConfig
        {
            linkMode = 2,
            decodeMode = 2,
            sensorIp = "",
            localIp = "",
            sensorPort = 5152,
            localPort = 0,
            serialPortName = "COM6",
            baudRate = 460800
        };

        int res = NativeMethods.kwSetConfig(0, ref config);
        if (res != 0)
        {
            Console.WriteLine("配置失败");
            return;
        }

        if (NativeMethods.kwStartCapture(0) != 0)
        {
            Console.WriteLine("采集启动失败");
            return;
        }

        float[] data = new float[6];

        for (int i = 0; i < 1000; i++)
        {
            int r = NativeMethods.kwGetCurrentForceData(0, data);
            if (r == 0)
            {
                Console.WriteLine($"fx:{data[0]}, fy:{data[1]}, fz:{data[2]}, mx:{data[3]}, my:{data[4]}, mz:{data[5]},");
            }
            else
            {
                Console.WriteLine($"读取失败: code={r}");
            }
            Thread.Sleep(10);
        }

        NativeMethods.kwStopCapture(0);
    }
}