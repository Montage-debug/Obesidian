#include <iostream>
#include <thread>
// #include <capturer.h>
#include <kwcapture.h>



#define MODE 0 // 0 串口, 1 TCP, 2 UDP
// 线程控制标识


int deviceIndex = 0; // 设备序号，第一个传感器为0， 第二个设备为1，后续进行递增. 序号数字不要超过99

bool capturing = true;

void test_tread_function()
{
    float force[6];
    uint64_t cnt = 0;
    uint64_t removeBytes = 0;
    int res;
    uint64_t totalBytes;

	while (capturing)
	{
        res = kwGetForceDataF(deviceIndex, force, &cnt, &totalBytes);

         if (res == 0)
         {
             fprintf(stderr, "cnt: %d fx: %.5f fy: %.5f fz: %.5f mx: %.5f my: %.5f mz: %.5f\n", cnt,
         		force[0], force[1], force[2], force[3], force[4], force[5]);

         	cnt++;
         }
	}
	printf("receive total frame: %d\n", cnt);
}




int main()
{
    SensorConfig cfg;
#if MODE == 0
    cfg.linkMode = 0;
    cfg.serialPortName = "/dev/ttyUSB0";
    cfg.baudRate = 460800;
    float para[] = {1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f}; // 长数据类型可不设置
    cfg.paras = para;
    cfg.decodeMode = 2;
#elif MODE == 1
    cfg.linkMode = 1;
    cfg.decodeMode = 2; // 30字节
    cfg.localIp = "192.168.1.100";
    cfg.localPort = 8886;
    cfg.sensorIp = "192.168.1.101";
    cfg.sensorPort = 5152;
    float para[] = {1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f};
    cfg.paras = para;
#elif MODE == 2
    cfg.linkMode = 2;
    cfg.decodeMode = 2; // 30字节
    cfg.localIp = "192.168.1.100";
    cfg.localPort = 8886;
    cfg.sensorIp = "192.168.1.101";
    cfg.sensorPort = 5152
    float para[] = {1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f};
    cfg.paras = para;
#endif

    if (kwSetConfig(deviceIndex, &cfg) != 0)
    {
        std::cerr << "set config error" << std::endl;
        return 1;
    }

    if (kwStartCapture(deviceIndex) != 0)
    {
        printf("start capture error\n");
        return 1;
    }

    std::thread thread(test_tread_function);

    std::this_thread::sleep_for(std::chrono::seconds(5));

    capturing = false;
    if (thread.joinable())
        thread.join();

    kwStopCapture(deviceIndex);
    kwResetConfig(deviceIndex);

    printf("停止采集成功\n");
    
    return 0;
}

