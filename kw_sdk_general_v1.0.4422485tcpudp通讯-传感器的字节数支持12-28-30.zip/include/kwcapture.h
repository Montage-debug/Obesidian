#ifndef KWCAPTURE_H
#define KWCAPTURE_H

#ifdef __linux
#define __stdcall
#endif

#include <inttypes.h>
#include <stddef.h>



#ifdef __cplusplus
extern "C"
{
#endif


struct SensorConfig
{
    int linkMode;

    int decodeMode = -1;

    float *paras = nullptr;

    const char *sensorIp = nullptr;

    unsigned short sensorPort = 5152;

    const char *localIp = nullptr;

    unsigned short localPort = 8886;

    const char *serialPortName = nullptr;

    int baudRate = 460800;
};


const char *__stdcall kwGetSdkVersion();

// 一般通用接口
int __stdcall kwSetConfig(int device_idx, const SensorConfig *cfg);


int __stdcall kwResetConfig(int device_idx);


int __stdcall kwStartCapture(int device_idx);


int __stdcall kwStopCapture(int device_idx);


int __stdcall kwGetForceDataF(
    int device_idx,
    float *data, 
    uint64_t *frameNum,
    size_t *totalBytes);


int __stdcall kwGetCurrentForceData(int device_idx, float *data);



// 扩展接口

struct kw_order
{
    const uint8_t *data;
    size_t size;
};


int __stdcall kwSetConfigEx(int device_idx,
                            int channel,
                            const SensorConfig *cfg);


int __stdcall kwResetConfigEx(int device_idx,
                              int channel);


int __stdcall kwStartCaptureEx(int device_idx,
                               int channel,
                               const kw_order *ords_);


int __stdcall kwStopCaptureEx(int device_idx, int channel);


int __stdcall kwGetForceDataEx(int device_idx, int channel,
                               float *data, uint64_t *frameNum,
                               size_t *totalBytes);


int __stdcall kwGetCurrentForceDataEx(int deice_idx,
                                      int channel,
                                      float *data);


#ifdef __cplusplus
}
#endif


#endif
